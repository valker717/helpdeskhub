package com.helpdesk;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.helpdesk.model.Category;
import com.helpdesk.model.Priority;
import com.helpdesk.model.TicketStatus;
import com.helpdesk.web.api.ApiModels.CreateComment;
import com.helpdesk.web.api.ApiModels.CreateTicket;
import com.helpdesk.web.api.ApiModels.UpdateTicket;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@SpringBootTest
@AutoConfigureMockMvc
class HelpDeskApplicationTests {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper mapper;

    @Test
    void homeListsSeededTicketsAndFiltersThem() throws Exception {
        mvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Заявки")))
                .andExpect(content().string(containsString("Нет доступа к 1С")));

        mvc.perform(get("/").param("status", "OPEN"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Нет доступа к 1С")))
                .andExpect(content().string(not(containsString("Сброс пароля VPN"))));

        mvc.perform(get("/css/app.css"))
                .andExpect(status().isOk());
    }

    @Test
    void ticketPageShowsComment() throws Exception {
        mvc.perform(get("/tickets/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Не печатает принтер")))
                .andExpect(content().string(containsString("заднюю крышку")));
    }

    @Test
    void formCreatesTicketAndRejectsEmptyFields() throws Exception {
        mvc.perform(get("/tickets/new"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Новая заявка")));

        mvc.perform(post("/tickets")
                        .characterEncoding(StandardCharsets.UTF_8)
                        .param("subject", " ")
                        .param("description", "")
                        .param("requesterName", "")
                        .param("requesterEmail", "not-an-email")
                        .param("category", "")
                        .param("priority", ""))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Укажите тему")));

        MvcResult created = mvc.perform(post("/tickets")
                        .characterEncoding(StandardCharsets.UTF_8)
                        .param("subject", "Не работает мышь")
                        .param("description", "В кабинете 12 курсор не двигается")
                        .param("requesterName", "Пётр")
                        .param("requesterEmail", "petr@example.com")
                        .param("category", "HARDWARE")
                        .param("priority", "LOW"))
                .andExpect(status().isFound())
                .andExpect(flash().attribute("message", containsString("создана")))
                .andReturn();

        mvc.perform(get(created.getResponse().getRedirectedUrl()))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Не работает мышь")));
    }

    @Test
    void apiCreatesUpdatesAndComments() throws Exception {
        mvc.perform(get("/api/meta"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.service").value("helpdesk"));

        byte[] body = mapper.writeValueAsBytes(new CreateTicket(
                "Тестовая заявка",
                "Проверка создания через API",
                "Анна Смирнова",
                "anna@example.com",
                Category.SOFTWARE,
                Priority.HIGH,
                null));

        MvcResult created = mvc.perform(post("/api/tickets")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andExpect(jsonPath("$.status").value("OPEN"))
                .andExpect(jsonPath("$.number").exists())
                .andReturn();

        JsonNode node = mapper.readTree(created.getResponse().getContentAsByteArray());
        long id = node.get("id").asLong();

        mvc.perform(patch("/api/tickets/" + id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsBytes(new UpdateTicket(TicketStatus.IN_PROGRESS, null, "Ольга"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("IN_PROGRESS"))
                .andExpect(jsonPath("$.assignee").value("Ольга"));

        mvc.perform(post("/api/tickets/" + id + "/comments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsBytes(new CreateComment("Ольга", "Взяла в работу"))))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.comments[0].body").value("Взяла в работу"));

        mvc.perform(patch("/api/tickets/" + id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsBytes(new UpdateTicket(null, null, ""))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.assignee").value(nullValue()));

        mvc.perform(post("/api/tickets")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("validation"))
                .andExpect(jsonPath("$.fields.subject").exists());

        mvc.perform(get("/api/tickets/999999"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").value("not_found"));
    }

    @Test
    void missingTicketPageIsNotFound() throws Exception {
        mvc.perform(get("/tickets/999999"))
                .andExpect(status().isNotFound())
                .andExpect(content().string(containsString("не найдена")));
    }
}
