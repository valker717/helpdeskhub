package com.helpdesk.service;

import com.helpdesk.model.Category;
import com.helpdesk.model.Comment;
import com.helpdesk.model.Priority;
import com.helpdesk.model.Ticket;
import com.helpdesk.model.TicketStatus;
import com.helpdesk.repo.TicketRepository;
import java.time.LocalDateTime;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class TicketService {

    private final TicketRepository tickets;

    public TicketService(TicketRepository tickets) {
        this.tickets = tickets;
    }

    @Transactional(readOnly = true)
    public List<Ticket> search(TicketStatus status, Priority priority, String query) {
        String needle = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (needle.length() > 100) {
            needle = needle.substring(0, 100);
        }
        String finalNeedle = needle;
        return tickets.findAllByOrderByCreatedAtDesc().stream()
                .filter(ticket -> status == null || ticket.getStatus() == status)
                .filter(ticket -> priority == null || ticket.getPriority() == priority)
                .filter(ticket -> matches(ticket, finalNeedle))
                .toList();
    }

    @Transactional(readOnly = true)
    public Ticket get(long id) {
        Ticket ticket = tickets.findById(id).orElseThrow(() -> new TicketNotFoundException(id));
        // The page reads comments after this transaction closes.
        Hibernate.initialize(ticket.getComments());
        return ticket;
    }

    @Transactional(readOnly = true)
    public Map<TicketStatus, Long> counts() {
        Map<TicketStatus, Long> counts = new EnumMap<>(TicketStatus.class);
        for (TicketStatus status : TicketStatus.values()) {
            counts.put(status, tickets.countByStatus(status));
        }
        return counts;
    }

    @Transactional(readOnly = true)
    public long count() {
        return tickets.count();
    }

    public Ticket create(String subject,
                         String description,
                         String requesterName,
                         String requesterEmail,
                         Category category,
                         Priority priority,
                         String assignee) {
        Ticket ticket = new Ticket();
        ticket.setSubject(subject.trim());
        ticket.setDescription(description.trim());
        ticket.setRequesterName(requesterName.trim());
        ticket.setRequesterEmail(requesterEmail.trim());
        ticket.setCategory(category);
        ticket.setPriority(priority);
        ticket.setStatus(TicketStatus.OPEN);
        ticket.setAssignee(blankToNull(assignee));
        return tickets.save(ticket);
    }

    public Ticket update(long id, TicketStatus status, Priority priority, String assignee, boolean changeAssignee) {
        Ticket ticket = load(id);
        if (status != null) {
            ticket.setStatus(status);
        }
        if (priority != null) {
            ticket.setPriority(priority);
        }
        if (changeAssignee) {
            ticket.setAssignee(blankToNull(assignee));
        }
        return ticket;
    }

    public Ticket updateFromDesk(long id, TicketStatus status, Priority priority, String assignee) {
        return update(id, status, priority, assignee, true);
    }

    public Ticket addComment(long id, String author, String body) {
        Ticket ticket = load(id);
        Comment comment = new Comment();
        comment.setAuthor(author.trim());
        comment.setBody(body.trim());
        ticket.addComment(comment);
        ticket.setUpdatedAt(LocalDateTime.now());
        return ticket;
    }

    private Ticket load(long id) {
        Ticket ticket = tickets.findById(id).orElseThrow(() -> new TicketNotFoundException(id));
        Hibernate.initialize(ticket.getComments());
        return ticket;
    }

    private boolean matches(Ticket ticket, String needle) {
        if (needle.isEmpty()) {
            return true;
        }
        return contains(ticket.getSubject(), needle)
                || contains(ticket.getDescription(), needle)
                || contains(ticket.getRequesterName(), needle)
                || contains(ticket.getRequesterEmail(), needle)
                || contains(ticket.getAssignee(), needle)
                || contains(ticket.getNumber(), needle)
                || String.valueOf(ticket.getId()).contains(needle)
                || contains(ticket.getCategory().getLabel(), needle)
                || contains(ticket.getPriority().getLabel(), needle)
                || contains(ticket.getStatus().getLabel(), needle);
    }

    private boolean contains(String value, String needle) {
        return value != null && value.toLowerCase(Locale.ROOT).contains(needle);
    }

    private String blankToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }
}
