package com.helpdesk.service;

public class TicketNotFoundException extends RuntimeException {

    private final long id;

    public TicketNotFoundException(long id) {
        super("Заявка не найдена: " + id);
        this.id = id;
    }

    public long getId() {
        return id;
    }
}
