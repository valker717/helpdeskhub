package com.helpdesk.web.api;

import com.helpdesk.model.Ticket;
import com.helpdesk.web.api.ApiModels.CommentView;
import com.helpdesk.web.api.ApiModels.TicketDetails;
import com.helpdesk.web.api.ApiModels.TicketSummary;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public final class TicketMapper {

    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    private TicketMapper() {
    }

    public static TicketSummary summary(Ticket ticket) {
        return new TicketSummary(
                ticket.getId(),
                ticket.getNumber(),
                ticket.getSubject(),
                ticket.getRequesterName(),
                ticket.getCategory().name(),
                ticket.getCategory().getLabel(),
                ticket.getPriority().name(),
                ticket.getPriority().getLabel(),
                ticket.getStatus().name(),
                ticket.getStatus().getLabel(),
                ticket.getAssignee(),
                time(ticket.getCreatedAt()),
                time(ticket.getUpdatedAt()));
    }

    public static TicketDetails details(Ticket ticket) {
        List<CommentView> comments = ticket.getComments().stream()
                .map(comment -> new CommentView(
                        comment.getId(),
                        comment.getAuthor(),
                        comment.getBody(),
                        time(comment.getCreatedAt())))
                .toList();
        return new TicketDetails(
                ticket.getId(),
                ticket.getNumber(),
                ticket.getSubject(),
                ticket.getDescription(),
                ticket.getRequesterName(),
                ticket.getRequesterEmail(),
                ticket.getCategory().name(),
                ticket.getCategory().getLabel(),
                ticket.getPriority().name(),
                ticket.getPriority().getLabel(),
                ticket.getStatus().name(),
                ticket.getStatus().getLabel(),
                ticket.getAssignee(),
                time(ticket.getCreatedAt()),
                time(ticket.getUpdatedAt()),
                comments);
    }

    private static String time(LocalDateTime value) {
        return value == null ? null : ISO.format(value);
    }
}
