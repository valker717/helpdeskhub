package com.helpdesk.web;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CommentForm {

    @NotBlank(message = "Укажите автора")
    @Size(max = 80, message = "Имя не длиннее 80 символов")
    private String author;

    @NotBlank(message = "Напишите комментарий")
    @Size(max = 2000, message = "Комментарий не длиннее 2000 символов")
    private String body;

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
}
