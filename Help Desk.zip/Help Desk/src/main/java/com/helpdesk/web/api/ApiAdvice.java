package com.helpdesk.web.api;

import com.helpdesk.service.TicketNotFoundException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@RestControllerAdvice(assignableTypes = TicketApiController.class)
public class ApiAdvice {

    @ExceptionHandler(TicketNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Map<String, Object> notFound(TicketNotFoundException exception) {
        return Map.of(
                "error", "not_found",
                "message", exception.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String, Object> invalid(MethodArgumentNotValidException exception) {
        Map<String, String> fields = new LinkedHashMap<>();
        exception.getBindingResult().getFieldErrors()
                .forEach(error -> fields.put(error.getField(), error.getDefaultMessage()));
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("error", "validation");
        body.put("message", "Проверьте поля запроса");
        body.put("fields", fields);
        return body;
    }

    @ExceptionHandler({HttpMessageNotReadableException.class, MethodArgumentTypeMismatchException.class})
    public ResponseEntity<Map<String, String>> unreadable(Exception exception) {
        String message = "Не удалось разобрать запрос. Проверьте JSON и значения category, priority, status.";
        if (exception instanceof MethodArgumentTypeMismatchException mismatch && mismatch.getName() != null) {
            message = "Некорректное значение параметра " + mismatch.getName();
        }
        return ResponseEntity.badRequest().body(Map.of(
                "error", "bad_request",
                "message", message));
    }
}
