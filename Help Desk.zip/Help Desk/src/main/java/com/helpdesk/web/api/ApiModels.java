package com.helpdesk.web.api;

import com.helpdesk.model.Category;
import com.helpdesk.model.Priority;
import com.helpdesk.model.TicketStatus;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;

public final class ApiModels {

    private ApiModels() {
    }

    public record CreateTicket(
            @NotBlank(message = "Укажите тему")
            @Size(max = 160, message = "Тема не длиннее 160 символов")
            String subject,
            @NotBlank(message = "Опишите проблему")
            @Size(max = 4000, message = "Описание не длиннее 4000 символов")
            String description,
            @NotBlank(message = "Укажите заявителя")
            @Size(max = 80, message = "Имя не длиннее 80 символов")
            String requesterName,
            @NotBlank(message = "Укажите почту")
            @Email(message = "Укажите корректную почту")
            @Size(max = 120, message = "Почта не длиннее 120 символов")
            String requesterEmail,
            @NotNull(message = "Выберите категорию")
            Category category,
            @NotNull(message = "Выберите приоритет")
            Priority priority,
            @Size(max = 80, message = "Имя исполнителя не длиннее 80 символов")
            String assignee
    ) {
    }

    public record UpdateTicket(
            TicketStatus status,
            Priority priority,
            @Size(max = 80, message = "Имя исполнителя не длиннее 80 символов")
            String assignee
    ) {
    }

    public record CreateComment(
            @NotBlank(message = "Укажите автора")
            @Size(max = 80, message = "Имя не длиннее 80 символов")
            String author,
            @NotBlank(message = "Напишите комментарий")
            @Size(max = 2000, message = "Комментарий не длиннее 2000 символов")
            String body
    ) {
    }

    public record CommentView(long id, String author, String body, String createdAt) {
    }

    public record TicketSummary(
            long id,
            String number,
            String subject,
            String requesterName,
            String category,
            String categoryLabel,
            String priority,
            String priorityLabel,
            String status,
            String statusLabel,
            String assignee,
            String createdAt,
            String updatedAt
    ) {
    }

    public record TicketDetails(
            long id,
            String number,
            String subject,
            String description,
            String requesterName,
            String requesterEmail,
            String category,
            String categoryLabel,
            String priority,
            String priorityLabel,
            String status,
            String statusLabel,
            String assignee,
            String createdAt,
            String updatedAt,
            List<CommentView> comments
    ) {
    }
}
