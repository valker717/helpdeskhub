package com.helpdesk.web;

import com.helpdesk.model.Priority;
import com.helpdesk.model.TicketStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class StatusForm {

    @NotNull(message = "Выберите статус")
    private TicketStatus status;

    @NotNull(message = "Выберите приоритет")
    private Priority priority;

    @Size(max = 80, message = "Имя исполнителя не длиннее 80 символов")
    private String assignee;

    public StatusForm() {
    }

    public StatusForm(TicketStatus status, Priority priority, String assignee) {
        this.status = status;
        this.priority = priority;
        this.assignee = assignee;
    }

    public TicketStatus getStatus() {
        return status;
    }

    public void setStatus(TicketStatus status) {
        this.status = status;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }
}
