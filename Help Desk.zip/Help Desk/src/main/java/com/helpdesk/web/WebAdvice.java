package com.helpdesk.web;

import com.helpdesk.service.TicketNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice(assignableTypes = DeskController.class)
public class WebAdvice {

    @ExceptionHandler(TicketNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String notFound(TicketNotFoundException exception, Model model) {
        model.addAttribute("missingId", exception.getId());
        model.addAttribute("nav", "list");
        return "not-found";
    }
}
