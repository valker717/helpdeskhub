package com.helpdesk.web;

import com.helpdesk.model.Category;
import com.helpdesk.model.Priority;
import com.helpdesk.model.Ticket;
import com.helpdesk.model.TicketStatus;
import com.helpdesk.service.TicketService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class DeskController {

    private final TicketService tickets;

    public DeskController(TicketService tickets) {
        this.tickets = tickets;
    }

    @InitBinder
    void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(Priority.class, new BlankToNullEnumEditor<>(Priority.class));
        binder.registerCustomEditor(Category.class, new BlankToNullEnumEditor<>(Category.class));
        binder.registerCustomEditor(TicketStatus.class, new BlankToNullEnumEditor<>(TicketStatus.class));
    }

    @GetMapping("/")
    public String index(@RequestParam(required = false) String status,
                        @RequestParam(required = false) String priority,
                        @RequestParam(required = false) String q,
                        Model model) {
        TicketStatus statusFilter = parse(TicketStatus.class, status);
        Priority priorityFilter = parse(Priority.class, priority);
        String query = q == null ? "" : q.trim();
        model.addAttribute("tickets", tickets.search(statusFilter, priorityFilter, query));
        model.addAttribute("counts", tickets.counts());
        model.addAttribute("total", tickets.count());
        model.addAttribute("statuses", TicketStatus.values());
        model.addAttribute("priorities", Priority.values());
        model.addAttribute("statusFilter", statusFilter);
        model.addAttribute("priorityFilter", priorityFilter);
        model.addAttribute("q", query);
        model.addAttribute("nav", "list");
        return "index";
    }

    @GetMapping("/tickets/new")
    public String createForm(Model model) {
        if (!model.containsAttribute("form")) {
            model.addAttribute("form", new TicketForm());
        }
        addFormOptions(model);
        model.addAttribute("nav", "new");
        return "form";
    }

    @PostMapping("/tickets")
    public String create(@Valid @ModelAttribute("form") TicketForm form,
                         BindingResult result,
                         RedirectAttributes redirect,
                         Model model) {
        if (result.hasErrors()) {
            addFormOptions(model);
            model.addAttribute("nav", "new");
            return "form";
        }
        Ticket ticket = tickets.create(
                form.getSubject(),
                form.getDescription(),
                form.getRequesterName(),
                form.getRequesterEmail(),
                form.getCategory(),
                form.getPriority(),
                form.getAssignee());
        redirect.addFlashAttribute("message", "Заявка " + ticket.getNumber() + " создана");
        return "redirect:/tickets/" + ticket.getId();
    }

    @GetMapping("/tickets/{id}")
    public String detail(@PathVariable long id, Model model) {
        return showTicket(tickets.get(id), model);
    }

    @PostMapping("/tickets/{id}/status")
    public String updateStatus(@PathVariable long id,
                               @Valid @ModelAttribute("statusForm") StatusForm form,
                               BindingResult result,
                               RedirectAttributes redirect,
                               Model model) {
        Ticket ticket = tickets.get(id);
        if (result.hasErrors()) {
            return showTicket(ticket, model);
        }
        tickets.updateFromDesk(id, form.getStatus(), form.getPriority(), form.getAssignee());
        redirect.addFlashAttribute("message", "Заявка обновлена");
        return "redirect:/tickets/" + id;
    }

    @PostMapping("/tickets/{id}/comments")
    public String addComment(@PathVariable long id,
                             @Valid @ModelAttribute("commentForm") CommentForm form,
                             BindingResult result,
                             RedirectAttributes redirect,
                             Model model) {
        Ticket ticket = tickets.get(id);
        if (result.hasErrors()) {
            return showTicket(ticket, model);
        }
        tickets.addComment(id, form.getAuthor(), form.getBody());
        redirect.addFlashAttribute("message", "Комментарий добавлен");
        return "redirect:/tickets/" + id;
    }

    private String showTicket(Ticket ticket, Model model) {
        model.addAttribute("ticket", ticket);
        if (!model.containsAttribute("commentForm")) {
            model.addAttribute("commentForm", new CommentForm());
        }
        if (!model.containsAttribute("statusForm")) {
            model.addAttribute("statusForm", new StatusForm(
                    ticket.getStatus(), ticket.getPriority(), ticket.getAssignee()));
        }
        model.addAttribute("statuses", TicketStatus.values());
        model.addAttribute("priorities", Priority.values());
        model.addAttribute("nav", "list");
        return "ticket";
    }

    private void addFormOptions(Model model) {
        model.addAttribute("categories", Category.values());
        model.addAttribute("priorities", Priority.values());
    }

    private static <E extends Enum<E>> E parse(Class<E> type, String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return Enum.valueOf(type, raw.trim());
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
