package com.helpdesk.web.api;

import com.helpdesk.model.Category;
import com.helpdesk.model.Labeled;
import com.helpdesk.model.Priority;
import com.helpdesk.model.Ticket;
import com.helpdesk.model.TicketStatus;
import com.helpdesk.service.TicketService;
import com.helpdesk.web.api.ApiModels.CreateComment;
import com.helpdesk.web.api.ApiModels.CreateTicket;
import com.helpdesk.web.api.ApiModels.TicketDetails;
import com.helpdesk.web.api.ApiModels.TicketSummary;
import com.helpdesk.web.api.ApiModels.UpdateTicket;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("/api")
public class TicketApiController {

    private final TicketService tickets;

    public TicketApiController(TicketService tickets) {
        this.tickets = tickets;
    }

    @GetMapping("/meta")
    public Map<String, Object> meta() {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("service", "helpdesk");
        body.put("tickets", tickets.count());
        body.put("categories", catalog(Category.values()));
        body.put("priorities", catalog(Priority.values()));
        body.put("statuses", catalog(TicketStatus.values()));
        return body;
    }

    @GetMapping("/tickets")
    public List<TicketSummary> list(@RequestParam(required = false) TicketStatus status,
                                    @RequestParam(required = false) Priority priority,
                                    @RequestParam(required = false) String q) {
        return tickets.search(status, priority, q).stream().map(TicketMapper::summary).toList();
    }

    @GetMapping("/tickets/{id}")
    public TicketDetails get(@PathVariable long id) {
        return TicketMapper.details(tickets.get(id));
    }

    @PostMapping("/tickets")
    public ResponseEntity<TicketDetails> create(@Valid @RequestBody CreateTicket request) {
        Ticket ticket = tickets.create(
                request.subject(),
                request.description(),
                request.requesterName(),
                request.requesterEmail(),
                request.category(),
                request.priority(),
                request.assignee());
        TicketDetails body = TicketMapper.details(tickets.get(ticket.getId()));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(ticket.getId())
                .toUri();
        return ResponseEntity.created(location).body(body);
    }

    @PatchMapping("/tickets/{id}")
    public ResponseEntity<?> update(@PathVariable long id, @Valid @RequestBody UpdateTicket request) {
        if (request.status() == null && request.priority() == null && request.assignee() == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "bad_request",
                    "message", "Укажите хотя бы одно поле: status, priority или assignee"));
        }
        boolean changeAssignee = request.assignee() != null;
        Ticket ticket = tickets.update(id, request.status(), request.priority(), request.assignee(), changeAssignee);
        return ResponseEntity.ok(TicketMapper.details(ticket));
    }

    @PostMapping("/tickets/{id}/comments")
    public ResponseEntity<TicketDetails> comment(@PathVariable long id, @Valid @RequestBody CreateComment request) {
        Ticket ticket = tickets.addComment(id, request.author(), request.body());
        return ResponseEntity.created(URI.create("/api/tickets/" + id + "/comments"))
                .body(TicketMapper.details(ticket));
    }

    private static List<Map<String, String>> catalog(Labeled[] values) {
        List<Map<String, String>> items = new ArrayList<>();
        for (Labeled value : values) {
            items.add(Map.of("code", ((Enum<?>) value).name(), "label", value.getLabel()));
        }
        return items;
    }
}
