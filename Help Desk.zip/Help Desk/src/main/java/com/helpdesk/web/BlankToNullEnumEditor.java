package com.helpdesk.web;

import java.beans.PropertyEditorSupport;

public class BlankToNullEnumEditor<T extends Enum<T>> extends PropertyEditorSupport {

    private final Class<T> type;

    public BlankToNullEnumEditor(Class<T> type) {
        this.type = type;
    }

    @Override
    public void setAsText(String text) {
        if (text == null || text.isBlank()) {
            setValue(null);
            return;
        }
        setValue(Enum.valueOf(type, text.trim()));
    }

    @Override
    public String getAsText() {
        Object value = getValue();
        return value instanceof Enum<?> enumerated ? enumerated.name() : "";
    }
}
