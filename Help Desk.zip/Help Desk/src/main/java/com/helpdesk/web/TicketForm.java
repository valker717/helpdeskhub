package com.helpdesk.web;

import com.helpdesk.model.Category;
import com.helpdesk.model.Priority;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class TicketForm {

    @NotBlank(message = "Укажите тему")
    @Size(max = 160, message = "Тема не длиннее 160 символов")
    private String subject;

    @NotBlank(message = "Опишите проблему")
    @Size(max = 4000, message = "Описание не длиннее 4000 символов")
    private String description;

    @NotBlank(message = "Укажите заявителя")
    @Size(max = 80, message = "Имя не длиннее 80 символов")
    private String requesterName;

    @NotBlank(message = "Укажите почту")
    @Email(message = "Укажите корректную почту")
    @Size(max = 120, message = "Почта не длиннее 120 символов")
    private String requesterEmail;

    @NotNull(message = "Выберите категорию")
    private Category category;

    @NotNull(message = "Выберите приоритет")
    private Priority priority;

    @Size(max = 80, message = "Имя исполнителя не длиннее 80 символов")
    private String assignee;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRequesterName() {
        return requesterName;
    }

    public void setRequesterName(String requesterName) {
        this.requesterName = requesterName;
    }

    public String getRequesterEmail() {
        return requesterEmail;
    }

    public void setRequesterEmail(String requesterEmail) {
        this.requesterEmail = requesterEmail;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }
}
