package com.helpdesk.repo;

import com.helpdesk.model.Ticket;
import com.helpdesk.model.TicketStatus;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

    List<Ticket> findAllByOrderByCreatedAtDesc();

    long countByStatus(TicketStatus status);
}
