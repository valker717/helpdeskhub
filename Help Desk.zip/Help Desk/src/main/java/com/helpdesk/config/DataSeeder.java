package com.helpdesk.config;

import com.helpdesk.model.Category;
import com.helpdesk.model.Comment;
import com.helpdesk.model.Priority;
import com.helpdesk.model.Ticket;
import com.helpdesk.model.TicketStatus;
import com.helpdesk.repo.TicketRepository;
import java.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    private final TicketRepository tickets;

    public DataSeeder(TicketRepository tickets) {
        this.tickets = tickets;
    }

    @Override
    public void run(String... args) {
        if (tickets.count() > 0) {
            return;
        }
        LocalDateTime now = LocalDateTime.now();

        Ticket printer = ticket(
                "Не печатает принтер в кабинете 314",
                "HP LaserJet на третьем этаже захватывает бумагу и останавливается. Индикатор замятия горит, хотя бумаги в тракте не видно.",
                "Ольга Белова",
                "olga.belova@example.com",
                Category.HARDWARE,
                Priority.HIGH,
                TicketStatus.IN_PROGRESS,
                "Марина Котова",
                now.minusHours(5));
        say(printer, "Марина Котова",
                "Посмотрела лоток, бумага нормальная. Сниму заднюю крышку после обеда.",
                now.minusHours(2));

        Ticket access = ticket(
                "Нет доступа к 1С",
                "После смены пароля не пускает в базу «Бухгалтерия». Ошибка: недостаточно прав.",
                "Павел Никитин",
                "pavel.nikitin@example.com",
                Category.ACCESS,
                Priority.CRITICAL,
                TicketStatus.OPEN,
                null,
                now.minusMinutes(40));

        Ticket mail = ticket(
                "Не открывается корпоративная почта",
                "Outlook на ноутбуке пишет, что сервер недоступен. В браузере веб-почта открывается.",
                "Светлана Орлова",
                "svetlana.orlova@example.com",
                Category.SOFTWARE,
                Priority.MEDIUM,
                TicketStatus.WAITING,
                "Илья Сорокин",
                now.minusDays(1));
        say(mail, "Илья Сорокин",
                "Похоже на профиль Outlook. Жду, когда пользователь будет на месте.",
                now.minusHours(20));

        Ticket wifi = ticket(
                "Wi-Fi в переговорной «Берёза» обрывается",
                "На планшетах для планёрок связь пропадает каждые десять минут. В соседних комнатах всё стабильно.",
                "Артём Лебедев",
                "artem.lebedev@example.com",
                Category.NETWORK,
                Priority.HIGH,
                TicketStatus.OPEN,
                null,
                now.minusHours(3));

        Ticket ide = ticket(
                "Установить среду разработки на новый ноутбук",
                "Нужны JDK 21, Git и редактор. Ноутбук уже в домене.",
                "Кирилл Морозов",
                "kirill.morozov@example.com",
                Category.SOFTWARE,
                Priority.LOW,
                TicketStatus.RESOLVED,
                "Илья Сорокин",
                now.minusDays(3));
        say(ide, "Илья Сорокин",
                "Поставил Temurin 21, Git и редактор. Ярлыки на рабочем столе.",
                now.minusDays(2));

        Ticket vpn = ticket(
                "Сброс пароля VPN",
                "Сотрудник забыл пароль от VPN и не может подключиться из дома.",
                "Елена Фомина",
                "elena.fomina@example.com",
                Category.ACCESS,
                Priority.MEDIUM,
                TicketStatus.CLOSED,
                "Марина Котова",
                now.minusDays(6));
        say(vpn, "Марина Котова",
                "Пароль сброшен, временный отправлен в мессенджер. Заявку закрываю.",
                now.minusDays(6).plusHours(2));

        Ticket mouse = ticket(
                "Нужна вторая мышь на ресепшен",
                "На ресепшене одна мышь на двоих. Нужна ещё одна проводная.",
                "Наталья Ершова",
                "natalia.ershova@example.com",
                Category.HARDWARE,
                Priority.LOW,
                TicketStatus.OPEN,
                null,
                now.minusDays(2));

        tickets.save(printer);
        tickets.save(access);
        tickets.save(mail);
        tickets.save(wifi);
        tickets.save(ide);
        tickets.save(vpn);
        tickets.save(mouse);
        log.info("Demo tickets created: {}", tickets.count());
    }

    private Ticket ticket(String subject,
                          String description,
                          String name,
                          String email,
                          Category category,
                          Priority priority,
                          TicketStatus status,
                          String assignee,
                          LocalDateTime createdAt) {
        Ticket ticket = new Ticket();
        ticket.setSubject(subject);
        ticket.setDescription(description);
        ticket.setRequesterName(name);
        ticket.setRequesterEmail(email);
        ticket.setCategory(category);
        ticket.setPriority(priority);
        ticket.setStatus(status);
        ticket.setAssignee(assignee);
        ticket.setCreatedAt(createdAt);
        ticket.setUpdatedAt(createdAt);
        return ticket;
    }

    private void say(Ticket ticket, String author, String body, LocalDateTime at) {
        Comment comment = new Comment();
        comment.setAuthor(author);
        comment.setBody(body);
        comment.setCreatedAt(at);
        ticket.addComment(comment);
        if (ticket.getUpdatedAt() == null || at.isAfter(ticket.getUpdatedAt())) {
            ticket.setUpdatedAt(at);
        }
    }
}
