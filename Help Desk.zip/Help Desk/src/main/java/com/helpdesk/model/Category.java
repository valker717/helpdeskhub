package com.helpdesk.model;

public enum Category implements Labeled {
    HARDWARE("Оборудование"),
    SOFTWARE("Программы"),
    ACCESS("Доступ"),
    NETWORK("Сеть"),
    OTHER("Другое");

    private final String label;

    Category(String label) {
        this.label = label;
    }

    @Override
    public String getLabel() {
        return label;
    }
}
