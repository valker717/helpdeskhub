package com.helpdesk.model;

public enum TicketStatus implements Labeled {
    OPEN("Открыта"),
    IN_PROGRESS("В работе"),
    WAITING("Ожидание"),
    RESOLVED("Решена"),
    CLOSED("Закрыта");

    private final String label;

    TicketStatus(String label) {
        this.label = label;
    }

    @Override
    public String getLabel() {
        return label;
    }
}
