package com.helpdesk.model;

public interface Labeled {

    String getLabel();
}
