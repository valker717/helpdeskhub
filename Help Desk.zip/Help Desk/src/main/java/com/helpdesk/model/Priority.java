package com.helpdesk.model;

public enum Priority implements Labeled {
    LOW("Низкий"),
    MEDIUM("Средний"),
    HIGH("Высокий"),
    CRITICAL("Критический");

    private final String label;

    Priority(String label) {
        this.label = label;
    }

    @Override
    public String getLabel() {
        return label;
    }
}
